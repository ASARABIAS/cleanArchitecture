class RepositorioEmpleados:
    def guardar(self, empleado):
        # Simulación de guardar en base de datos
        print(f"Guardando {empleado.nombre} en la base de datos.")
