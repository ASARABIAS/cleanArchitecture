class ImpresoraEmpleado:
    @staticmethod
    def imprimir_detalles_empleado(empleado):
        print(f"Empleado: {empleado.nombre}, Salario: {empleado.salario}, Bonus: {empleado.bonus}")
