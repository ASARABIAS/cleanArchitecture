class AdminController:
    def dashboard(self):
        return "Panel de Administración"
    
    def configuraciones(self):
        return "Configuraciones del Sistema"
