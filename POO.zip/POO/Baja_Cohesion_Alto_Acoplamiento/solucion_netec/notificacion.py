class Notificador:
    def enviar_notificacion(self, empleado, mensaje):
        print(f"Enviando notificacin a {empleado.nombre}: {mensaje}")
